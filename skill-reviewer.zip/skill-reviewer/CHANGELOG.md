# Changelog

## v1.0.0 — 2026-03-18

Initial release.

### Dimensions
- Dim 1: Description / Trigger
- Dim 2: Gotchas Section
- Dim 3: Progressive Disclosure
- Dim 4: Railroading
- Dim 5: Setup & Config
- Dim 6: Scripts & Code
- Dim 7: Memory / State
- Dim 8: Context Efficiency (with existence flag)

### Design decisions
- All dimension rubrics split into individual files under `references/dims/` for lazy loading
- Conditional load table in SKILL.md maps diagnostic scenarios to specific dim files
- Overall score excludes N/A dimensions from denominator
- Dim 8 existence concern is a flag, not a scored dimension
- Description recommended range: 40–80 words
